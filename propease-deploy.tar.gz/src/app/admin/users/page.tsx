"use client";
import { useState, useEffect } from "react";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import { api } from "@/lib/api-client";

interface ApiUser { id: string; name: string; email: string; role: string; city: string | null; walletBalance: number; isApproved: boolean; isVerified: boolean; canCreateTasks: boolean; canCloseDeals: boolean; ambassadorId: string | null; whatsapp: string | null; createdAt: string; }

export default function UsersPage() {
  const [users, setUsers] = useState<ApiUser[]>([]);
  const [viewUser, setViewUser] = useState<ApiUser | null>(null);
  const [saving, setSaving] = useState<string | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);
  const [showCreate, setShowCreate] = useState(false);
  const [createForm, setCreateForm] = useState({ name: "", email: "", password: "", role: "client" as string, city: "" });
  const [creating, setCreating] = useState(false);
  const [createError, setCreateError] = useState("");
  const [messageUser, setMessageUser] = useState<ApiUser | null>(null);
  const [messageText, setMessageText] = useState("");
  const [sendingMessage, setSendingMessage] = useState(false);

  const fetchUsers = () => {
    api.get<{ users: ApiUser[] }>("/api/admin/users").then(r => { if (r.data?.users) setUsers(r.data.users); });
  };
  useEffect(() => { fetchUsers(); }, []);

  const toggleApprove = async (u: ApiUser) => {
    setSaving(u.id);
    await api.patch(`/api/admin/users/${u.id}`, { isApproved: !u.isApproved, suspendedAt: u.isApproved ? new Date().toISOString() : null });
    fetchUsers();
    setSaving(null);
  };

  const deleteUser = async (u: ApiUser) => {
    setDeleting(u.id);
    await api.delete(`/api/admin/users/${u.id}`);
    fetchUsers();
    setDeleting(null);
    setViewUser(null);
  };

  const createUser = async () => {
    setCreateError("");
    if (!createForm.name || !createForm.email || !createForm.password) {
      setCreateError("Name, email, and password are required");
      return;
    }
    if (createForm.password.length < 8) {
      setCreateError("Password must be at least 8 characters");
      return;
    }
    setCreating(true);
    const { status, error } = await api.post("/api/admin/users", createForm);
    setCreating(false);
    if (status === 201 || status === 200) {
      setShowCreate(false);
      setCreateForm({ name: "", email: "", password: "", role: "client", city: "" });
      fetchUsers();
    } else if (status === 409) {
      setCreateError("Email already exists");
    } else {
      setCreateError(error || "Failed to create user");
    }
  };

  const sendMessage = async () => {
    if (!messageText.trim() || !messageUser) return;
    setSendingMessage(true);
    const { status } = await api.post(`/api/admin/users/${messageUser.id}/message`, { message: messageText });
    setSendingMessage(false);
    if (status === 200) {
      setMessageUser(null);
      setMessageText("");
    }
  };

  const filtered = users;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <a href="/admin" className="text-gray-400 hover:text-[var(--color-primary)]"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}><path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18"/></svg></a>
          <div><h1 className="text-xl font-bold text-gray-900">Users</h1><p className="text-xs text-gray-500">Manage all platform users</p></div>
        </div>
        <Button onClick={() => setShowCreate(true)} size="sm">+ Add User</Button>
      </div>

      {/* Create User Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setShowCreate(false)}>
          <div className="bg-white rounded-xl p-6 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-bold text-gray-900">Create New User</h3>
              <button onClick={() => setShowCreate(false)} className="text-gray-400 hover:text-gray-600"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Full Name *</label>
                <input value={createForm.name} onChange={e => setCreateForm(p => ({ ...p, name: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="e.g. Ahmad Ibrahim" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Email *</label>
                <input type="email" value={createForm.email} onChange={e => setCreateForm(p => ({ ...p, email: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="user@email.com" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Password *</label>
                <input type="password" value={createForm.password} onChange={e => setCreateForm(p => ({ ...p, password: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="Min 8 characters" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Role</label>
                <select value={createForm.role} onChange={e => setCreateForm(p => ({ ...p, role: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm">
                  <option value="client">Client</option>
                  <option value="agent">Agent</option>
                  <option value="ambassador">Ambassador</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">City</label>
                <input value={createForm.city} onChange={e => setCreateForm(p => ({ ...p, city: e.target.value }))} className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm" placeholder="e.g. Kano Municipal" />
              </div>
              {createError && <div className="bg-red-50 border border-red-200 text-red-700 text-xs px-3 py-2 rounded-lg">{createError}</div>}
              <Button className="w-full" onClick={createUser} disabled={creating}>{creating ? "Creating..." : "Create User"}</Button>
            </div>
          </div>
        </div>
      )}

      <div className="hidden md:block bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead><tr className="border-b border-gray-100 bg-gray-50 text-left"><th className="px-4 py-3 text-xs font-medium text-gray-600">User</th><th className="px-4 py-3 text-xs font-medium text-gray-600">Role</th><th className="px-4 py-3 text-xs font-medium text-gray-600">City</th><th className="px-4 py-3 text-xs font-medium text-gray-600">Status</th><th className="px-4 py-3 text-xs font-medium text-gray-600">Wallet</th><th className="px-4 py-3 text-xs font-medium text-gray-600">Actions</th></tr></thead>
            <tbody>
              {filtered.map(u => (
                <tr key={u.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                  <td className="px-4 py-3"><div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-[var(--color-primary)]/10 flex items-center justify-center text-xs font-bold text-[var(--color-primary)]">{u.name.split(" ").map(n=>n[0]).join("")}</div><div><p className="font-medium text-gray-900 text-xs">{u.name}</p><p className="text-[10px] text-gray-400">{u.email}</p></div></div></td>
                  <td className="px-4 py-3"><Badge>{u.role}</Badge></td>
                  <td className="px-4 py-3 text-xs text-gray-600">{u.city||"N/A"}</td>
                  <td className="px-4 py-3"><Badge variant={u.isApproved?"success":"warning"}>{u.isApproved?"Active":"Pending"}</Badge></td>
                  <td className="px-4 py-3 text-xs font-medium text-gray-900">₦{u.walletBalance.toLocaleString()}</td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1.5">
                      <Button size="sm" variant="ghost" onClick={() => setViewUser(u)}>View</Button>
                      <Button size="sm" variant="ghost" onClick={() => setMessageUser(u)}>Message</Button>
                      {u.role!=="head"&&<Button size="sm" variant={u.isApproved?"outline":"primary"} onClick={()=>toggleApprove(u)} disabled={saving===u.id}>{u.isApproved?"Suspend":"Approve"}</Button>}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="md:hidden space-y-3">
        {filtered.map(u => (
          <div key={u.id} className="bg-white rounded-xl border border-gray-200 p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-full bg-[var(--color-primary)]/10 flex items-center justify-center text-sm font-bold text-[var(--color-primary)]">{u.name.split(" ").map(n=>n[0]).join("")}</div>
              <div className="min-w-0 flex-1">
                <p className="font-medium text-gray-900 text-sm truncate">{u.name}</p>
                <p className="text-xs text-gray-400 truncate">{u.email}</p>
              </div>
              <Badge variant={u.isApproved?"success":"warning"}>{u.isApproved?"Active":"Pending"}</Badge>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs mb-3">
              <div><span className="text-gray-400">Role</span><p className="font-medium capitalize">{u.role}</p></div>
              <div><span className="text-gray-400">City</span><p className="font-medium">{u.city||"N/A"}</p></div>
              <div><span className="text-gray-400">Wallet</span><p className="font-medium">₦{u.walletBalance.toLocaleString()}</p></div>
              <div><span className="text-gray-400">Joined</span><p className="font-medium">{new Date(u.createdAt).toLocaleDateString()}</p></div>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="ghost" className="flex-1" onClick={() => setViewUser(u)}>View</Button>
              {u.role!=="head"&&<Button size="sm" variant={u.isApproved?"outline":"primary"} className="flex-1" onClick={()=>toggleApprove(u)} disabled={saving===u.id}>{u.isApproved?"Suspend":"Approve"}</Button>}
            </div>
          </div>
        ))}
        {filtered.length === 0 && <div className="bg-white rounded-xl border border-gray-200 p-8 text-center text-gray-400 text-sm">No users found.</div>}
      </div>

      {viewUser && <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={()=>setViewUser(null)}><div className="bg-white rounded-xl p-6 max-w-lg w-full shadow-2xl" onClick={e=>e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4"><h3 className="text-lg font-bold text-gray-900">{viewUser.name}</h3><button onClick={()=>setViewUser(null)} className="text-gray-400 hover:text-gray-600"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button></div>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div><span className="text-gray-400 text-xs">Email</span><p className="font-medium">{viewUser.email}</p></div>
          <div><span className="text-gray-400 text-xs">Role</span><p className="font-medium capitalize">{viewUser.role}</p></div>
          <div><span className="text-gray-400 text-xs">City</span><p className="font-medium">{viewUser.city||"N/A"}</p></div>
          <div><span className="text-gray-400 text-xs">Status</span><Badge variant={viewUser.isApproved?"success":"warning"}>{viewUser.isApproved?"Approved":"Pending"}</Badge></div>
          <div><span className="text-gray-400 text-xs">Wallet</span><p className="font-medium">₦{viewUser.walletBalance.toLocaleString()}</p></div>
          <div><span className="text-gray-400 text-xs">Verified</span><p className="font-medium">{viewUser.isVerified?"Yes":"No"}</p></div>
        </div>
        <div className="mt-4 flex gap-2">{viewUser.role!=="head"&&<><Button variant="outline" size="sm" className="flex-1" onClick={()=>{toggleApprove(viewUser);setViewUser(null)}}>{viewUser.isApproved?"Suspend":"Approve"}</Button><Button variant="danger" size="sm" className="flex-1" disabled={deleting===viewUser.id} onClick={()=>deleteUser(viewUser)}>{deleting===viewUser.id?"Deleting...":"Delete"}</Button></>}</div>
      </div></div>}

      {/* Message User Modal */}
      {messageUser && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setMessageUser(null)}>
          <div className="bg-white rounded-xl p-6 max-w-md w-full shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-lg font-bold text-gray-900">Send Message</h3>
                <p className="text-xs text-gray-500">To: {messageUser.name} ({messageUser.email})</p>
              </div>
              <button onClick={() => setMessageUser(null)} className="text-gray-400 hover:text-gray-600"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg></button>
            </div>
            <textarea
              value={messageText}
              onChange={e => setMessageText(e.target.value)}
              placeholder="Type your message..."
              rows={5}
              className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm resize-none focus:outline-none focus:ring-1 focus:ring-[var(--color-primary)]"
            />
            <p className="text-[10px] text-gray-400 mt-1 mb-3">User will receive this via email and in-app notification.</p>
            <Button className="w-full" onClick={sendMessage} disabled={!messageText.trim() || sendingMessage}>
              {sendingMessage ? "Sending..." : "Send Message"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
